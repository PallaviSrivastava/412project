How to run DBSCAN.py file:
1. Put the exported JSON file in the same folder with DBSCAN.
2. In the DBSCAN.py file, change the input file name, epsilon and feature weight.
3. Run the code.